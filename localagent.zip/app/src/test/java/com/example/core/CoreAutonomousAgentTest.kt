package com.example.core

import com.example.core.engine.BenchmarkHarness
import com.example.core.model.StepStatus
import com.example.core.model.TargetSelector
import com.example.core.model.TaskCommand
import com.example.core.model.VerificationRule
import com.example.core.parser.NaturalLanguageCommandParser
import com.example.core.resolver.TargetResolver
import com.example.core.verifier.StepVerifier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CoreAutonomousAgentTest {

    @Test
    fun testCommandParser_calculatorLaunchAndTap7() {
        val parser = NaturalLanguageCommandParser()
        val commands = parser.parse("Launch Calculator and tap 7")

        assertTrue("Should produce at least 3 commands", commands.size >= 3)
        assertTrue("First command should be LaunchApp", commands[0] is TaskCommand.LaunchApp)
        val clickCmd = commands.find { it is TaskCommand.ClickElement } as? TaskCommand.ClickElement
        assertNotNull("Should contain ClickElement command", clickCmd)
        assertEquals("7", clickCmd?.selector?.text)

        val verifyCmd = commands.find { it is TaskCommand.VerifyCondition } as? TaskCommand.VerifyCondition
        assertNotNull("Should contain VerifyCondition command", verifyCmd)
        assertTrue(verifyCmd?.rule is VerificationRule.DisplayContainsText)
    }

    @Test
    fun testTargetResolver_locatesDigit7InCalculatorHierarchy() {
        val snapshot = BenchmarkHarness.createCalculatorInitialSnapshot()
        val resolver = TargetResolver()

        val result = resolver.resolve(
            selector = TargetSelector(text = "7"),
            snapshot = snapshot,
            currentTimeMs = snapshot.timestampMs + 100
        )

        assertTrue("Resolution should succeed", result is TargetResolver.ResolutionResult.Success)
        val success = result as TargetResolver.ResolutionResult.Success
        assertEquals("7", success.match.node.text)
        assertEquals("com.google.android.calculator:id/digit_7", success.match.node.resourceId)
        assertTrue("Score should be high", success.match.score >= 80)
    }

    @Test
    fun testTargetResolver_rejectsStaleSnapshot() {
        val snapshot = BenchmarkHarness.createCalculatorInitialSnapshot()
        val resolver = TargetResolver(maxSnapshotStalenessMs = 2000L)

        // Snapshot timestamp is 5000ms old
        val result = resolver.resolve(
            selector = TargetSelector(text = "7"),
            snapshot = snapshot,
            currentTimeMs = snapshot.timestampMs + 5000L
        )

        assertTrue("Should reject stale snapshot", result is TargetResolver.ResolutionResult.Failure)
        val failure = result as TargetResolver.ResolutionResult.Failure
        assertTrue(failure.reason.contains("Stale snapshot rejected"))
    }

    @Test
    fun testStepVerifier_calculatorDigitDisplayVerified() {
        val preSnapshot = BenchmarkHarness.createCalculatorInitialSnapshot()
        val postSnapshot = BenchmarkHarness.createCalculatorAfterDigitSnapshot("7")
        val verifier = StepVerifier()

        val outcome = verifier.verify(
            command = TaskCommand.VerifyCondition(
                rule = VerificationRule.DisplayContainsText("7"),
                requirementDescription = "Calculator formula contains 7"
            ),
            preSnapshot = preSnapshot,
            postSnapshot = postSnapshot,
            actionDispatchedTimestampMs = postSnapshot.timestampMs - 200,
            currentTimeMs = postSnapshot.timestampMs + 50
        )

        assertEquals("Outcome should be SUCCESS", StepStatus.SUCCESS, outcome.status)
        assertTrue(outcome.reason.contains("contains '7'"))
    }

    @Test
    fun testStepVerifier_rejectsStalePostActionSnapshot() {
        val preSnapshot = BenchmarkHarness.createCalculatorInitialSnapshot()
        val postSnapshot = BenchmarkHarness.createCalculatorAfterDigitSnapshot("7")
        val verifier = StepVerifier()

        // Action dispatched AFTER postSnapshot was captured
        val outcome = verifier.verify(
            command = TaskCommand.ClickElement(selector = TargetSelector(text = "7")),
            preSnapshot = preSnapshot,
            postSnapshot = postSnapshot,
            actionDispatchedTimestampMs = postSnapshot.timestampMs + 500,
            currentTimeMs = postSnapshot.timestampMs + 1000
        )

        assertEquals("Outcome must be INCONCLUSIVE for stale observation", StepStatus.INCONCLUSIVE, outcome.status)
        assertTrue(outcome.reason.contains("stale"))
    }

    @Test
    fun testRecorderAndSynthesizer_convertsInteractionsToAutonomousPlan() {
        val recorder = com.example.core.recorder.VisualInteractionRecorder()
        recorder.startRecording()

        recorder.recordTap(
            node = null,
            coordinates = Pair(200, 400),
            packageName = "com.google.android.calculator"
        )
        recorder.recordTextEntry(
            text = "42",
            packageName = "com.google.android.calculator"
        )
        recorder.recordScroll(
            direction = com.example.core.model.ScrollDirection.DOWN,
            packageName = "com.google.android.calculator"
        )
        recorder.recordDrawerAction(
            isOpen = true,
            packageName = "com.google.android.calculator"
        )

        val recordedEvents = recorder.stopRecording()
        assertEquals("Should have recorded 4 interaction events", 4, recordedEvents.size)

        val synthesizer = com.example.core.recorder.TaskSynthesizer()
        val synthesizedTask = synthesizer.synthesize(
            interactions = recordedEvents,
            taskName = "Calculator Automation Flow"
        )

        assertEquals("Calculator Automation Flow", synthesizedTask.name)
        assertTrue("Synthesized commands must include LaunchApp, Tap, EnterText, Scroll, and Drawer", synthesizedTask.commands.size >= 4)
        assertTrue(synthesizedTask.commands.any { it is TaskCommand.LaunchApp })
        assertTrue(synthesizedTask.commands.any { it is TaskCommand.ClickElement })
        assertTrue(synthesizedTask.commands.any { it is TaskCommand.EnterText })
        assertTrue(synthesizedTask.commands.any { it is TaskCommand.Scroll })
        assertTrue(synthesizedTask.commands.any { it is TaskCommand.OpenDrawer })
    }

    @Test
    fun testCommandParser_scrollAndDrawerSkills() {
        val parser = NaturalLanguageCommandParser()

        val scrollCmds = parser.parse("scroll down")
        assertTrue(scrollCmds.first() is TaskCommand.Scroll)
        assertEquals(com.example.core.model.ScrollDirection.DOWN, (scrollCmds.first() as TaskCommand.Scroll).direction)

        val drawerCmds = parser.parse("open navigation drawer")
        assertTrue(drawerCmds.first() is TaskCommand.OpenDrawer)

        val typeCmds = parser.parse("enter LocalAgent into Search")
        assertTrue(typeCmds.any { it is TaskCommand.EnterText })
        val enterCmd = typeCmds.find { it is TaskCommand.EnterText } as TaskCommand.EnterText
        assertEquals("LocalAgent", enterCmd.textToEnter)
    }

    @Test
    fun testStepVerifier_scrollAndDrawerVerification() {
        val verifier = StepVerifier()
        val pre = BenchmarkHarness.createCalculatorInitialSnapshot()
        val post = BenchmarkHarness.createCalculatorAfterDigitSnapshot("7")

        val scrollOutcome = verifier.verify(
            command = TaskCommand.Scroll(direction = com.example.core.model.ScrollDirection.DOWN),
            preSnapshot = pre,
            postSnapshot = post,
            actionDispatchedTimestampMs = post.timestampMs - 200,
            currentTimeMs = post.timestampMs + 50
        )
        assertEquals(StepStatus.SUCCESS, scrollOutcome.status)

        val drawerOutcome = verifier.verify(
            command = TaskCommand.OpenDrawer(),
            preSnapshot = pre,
            postSnapshot = post,
            actionDispatchedTimestampMs = post.timestampMs - 200,
            currentTimeMs = post.timestampMs + 50
        )
        assertEquals(StepStatus.SUCCESS, drawerOutcome.status)
    }

    @Test
    fun testSnapshotDiffer_detectsFormulaMutation() {
        val pre = BenchmarkHarness.createCalculatorInitialSnapshot()
        val post = BenchmarkHarness.createCalculatorAfterDigitSnapshot("7")

        val diff = com.example.core.engine.SnapshotDiffer.computeDiff(pre, post)
        assertNotNull(diff)
        assertTrue("Should detect mutated nodes", diff.mutatedNodes.isNotEmpty())
        val mutation = diff.mutatedNodes.first()
        assertEquals("Formula view should be the mutated element", "formula_view", mutation.first.id)
        assertEquals("", mutation.first.text)
        assertEquals("7", mutation.second.text)
        assertTrue(diff.summary.contains("mutated"))
    }

    @Test
    fun testSnapshotStorage_cachesAndRetrieves() {
        val snapshot = BenchmarkHarness.createCalculatorInitialSnapshot()
        com.example.core.engine.SnapshotStorage.saveSnapshot(snapshot)

        val retrieved = com.example.core.engine.SnapshotStorage.getSnapshot(snapshot.id)
        assertNotNull(retrieved)
        assertEquals(snapshot.id, retrieved?.id)
        assertEquals(snapshot.packageName, retrieved?.packageName)
    }

    @Test
    fun testCommandParser_compoundCommandsAndOfflineDigits() {
        val parser = NaturalLanguageCommandParser()

        // Compound command test
        val compound = parser.parse("open settings and scroll down")
        assertTrue("Should produce compound commands", compound.size >= 2)
        assertTrue("First should be LaunchApp", compound[0] is TaskCommand.LaunchApp)
        assertTrue("Should contain Scroll", compound.any { it is TaskCommand.Scroll })

        // General digit test
        val digitCmds = parser.parse("Launch Calculator and tap 9")
        val click9 = digitCmds.find { it is TaskCommand.ClickElement } as? TaskCommand.ClickElement
        assertNotNull("Should find click for digit 9", click9)
        assertEquals("9", click9?.selector?.text)
    }

    @Test
    fun testTaskSynthesizer_encodeAndDecodeCommands() {
        val synthesizer = com.example.core.recorder.TaskSynthesizer()
        val original = listOf(
            TaskCommand.LaunchApp(packageName = "com.android.settings", appName = "Settings"),
            TaskCommand.ClickElement(selector = TargetSelector(text = "Wi-Fi"), targetLabel = "Wi-Fi"),
            TaskCommand.EnterText(selector = TargetSelector(className = "EditText"), textToEnter = "LocalAgentNet"),
            TaskCommand.Scroll(direction = com.example.core.model.ScrollDirection.DOWN),
            TaskCommand.OpenDrawer(),
            TaskCommand.CloseDrawer()
        )

        val encoded = synthesizer.encodeCommands(original)
        assertTrue("Encoded payload should not be blank", encoded.isNotBlank())

        val decoded = synthesizer.decodeCommands(encoded)
        assertEquals("Decoded command count must match original", original.size, decoded.size)
        assertTrue("First command should be LaunchApp", decoded[0] is TaskCommand.LaunchApp)
        assertTrue("Second command should be ClickElement", decoded[1] is TaskCommand.ClickElement)
        assertTrue("Third command should be EnterText", decoded[2] is TaskCommand.EnterText)
        assertTrue("Fourth command should be Scroll", decoded[3] is TaskCommand.Scroll)
    }

    @Test
    fun testCommandParser_actuatorsHardwareControl() {
        val parser = NaturalLanguageCommandParser()

        val vibrateCmds = parser.parse("vibrate phone")
        assertTrue("Should parse vibrate command", vibrateCmds.isNotEmpty())
        assertTrue("Command should be ControlActuator", vibrateCmds[0] is TaskCommand.ControlActuator)
        val act1 = vibrateCmds[0] as TaskCommand.ControlActuator
        assertEquals(com.example.core.model.ActuatorType.HAPTIC_PULSE, act1.actuatorType)

        val torchCmds = parser.parse("turn on flashlight")
        assertTrue("Should parse torch on command", torchCmds.isNotEmpty())
        val act2 = torchCmds[0] as TaskCommand.ControlActuator
        assertEquals(com.example.core.model.ActuatorType.TORCH_ON, act2.actuatorType)

        val beepCmds = parser.parse("play beep")
        assertTrue("Should parse chime command", beepCmds.isNotEmpty())
        val act3 = beepCmds[0] as TaskCommand.ControlActuator
        assertEquals(com.example.core.model.ActuatorType.AUDIO_TONE, act3.actuatorType)

        val wifiCmds = parser.parse("open wifi settings")
        assertTrue("Should parse wifi settings command", wifiCmds.isNotEmpty())
        val act4 = wifiCmds[0] as TaskCommand.ControlActuator
        assertEquals(com.example.core.model.ActuatorType.SETTINGS_WIFI, act4.actuatorType)
    }

    @Test
    fun testSnapshotDiffer_dualViewTreesNodeDiff() {
        val pre = BenchmarkHarness.createCalculatorInitialSnapshot()
        val post = BenchmarkHarness.createCalculatorAfterDigitSnapshot("7")

        val diff = com.example.core.engine.SnapshotDiffer.computeDiff(pre, post)

        assertEquals("Should have exactly 1 mutated node", 1, diff.mutatedNodes.size)
        val (preNode, postNode) = diff.mutatedNodes.first()
        assertEquals("formula_view", preNode.id)
        assertEquals("", preNode.text)
        assertEquals("7", postNode.text)
        assertTrue("Unchanged count should be greater than 20", diff.unchangedCount >= 20)
        assertNotNull("Added nodes list must be initialized", diff.addedNodes)
        assertNotNull("Removed nodes list must be initialized", diff.removedNodes)
    }

    @Test
    fun testTaskSynthesizer_actuatorCommandEncoding() {
        val synthesizer = com.example.core.recorder.TaskSynthesizer()
        val actuatorCmd = TaskCommand.ControlActuator(
            actuatorType = com.example.core.model.ActuatorType.TORCH_TOGGLE,
            param = "50",
            durationMs = 300L
        )

        val encoded = synthesizer.encodeCommands(listOf(actuatorCmd))
        assertTrue(encoded.contains("ACTUATOR|TORCH_TOGGLE|50|300"))

        val decoded = synthesizer.decodeCommands(encoded)
        assertEquals(1, decoded.size)
        assertTrue(decoded[0] is TaskCommand.ControlActuator)
        val decodedAct = decoded[0] as TaskCommand.ControlActuator
        assertEquals(com.example.core.model.ActuatorType.TORCH_TOGGLE, decodedAct.actuatorType)
        assertEquals("50", decodedAct.param)
        assertEquals(300L, decodedAct.durationMs)
    }

    @Test
    fun testCommandParser_wifiToggleCommands() {
        val parser = NaturalLanguageCommandParser()

        val onCmds1 = parser.parse("turn on wifi")
        assertTrue(onCmds1.isNotEmpty() && onCmds1[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.WIFI_ON, (onCmds1[0] as TaskCommand.ControlActuator).actuatorType)

        val onCmds2 = parser.parse("on wifi")
        assertTrue(onCmds2.isNotEmpty() && onCmds2[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.WIFI_ON, (onCmds2[0] as TaskCommand.ControlActuator).actuatorType)

        val offCmds1 = parser.parse("turn off wifi")
        assertTrue(offCmds1.isNotEmpty() && offCmds1[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.WIFI_OFF, (offCmds1[0] as TaskCommand.ControlActuator).actuatorType)

        val offCmds2 = parser.parse("off wifi")
        assertTrue(offCmds2.isNotEmpty() && offCmds2[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.WIFI_OFF, (offCmds2[0] as TaskCommand.ControlActuator).actuatorType)
    }

    @Test
    fun testCommandParser_bluetoothToggleCommands() {
        val parser = NaturalLanguageCommandParser()

        val onCmds1 = parser.parse("turn on bluetooth")
        assertTrue(onCmds1.isNotEmpty() && onCmds1[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.BLUETOOTH_ON, (onCmds1[0] as TaskCommand.ControlActuator).actuatorType)

        val onCmds2 = parser.parse("on bluetooth")
        assertTrue(onCmds2.isNotEmpty() && onCmds2[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.BLUETOOTH_ON, (onCmds2[0] as TaskCommand.ControlActuator).actuatorType)

        val offCmds1 = parser.parse("turn off bluetooth")
        assertTrue(offCmds1.isNotEmpty() && offCmds1[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.BLUETOOTH_OFF, (offCmds1[0] as TaskCommand.ControlActuator).actuatorType)

        val offCmds2 = parser.parse("off bluetooth")
        assertTrue(offCmds2.isNotEmpty() && offCmds2[0] is TaskCommand.ControlActuator)
        assertEquals(com.example.core.model.ActuatorType.BLUETOOTH_OFF, (offCmds2[0] as TaskCommand.ControlActuator).actuatorType)
    }

    @Test
    fun testCommandParser_timerCommands() {
        val parser = NaturalLanguageCommandParser()

        val t5m = parser.parse("start timer 5 minutes")
        assertTrue(t5m.isNotEmpty() && t5m[0] is TaskCommand.StartTimer)
        val timer1 = t5m[0] as TaskCommand.StartTimer
        assertEquals(300, timer1.durationSeconds)

        val t10s = parser.parse("set a timer for 10 seconds")
        assertTrue(t10s.isNotEmpty() && t10s[0] is TaskCommand.StartTimer)
        val timer2 = t10s[0] as TaskCommand.StartTimer
        assertEquals(10, timer2.durationSeconds)

        val typoTimer = parser.parse("start timeer")
        assertTrue(typoTimer.isNotEmpty() && typoTimer[0] is TaskCommand.StartTimer)
        val timer3 = typoTimer[0] as TaskCommand.StartTimer
        assertEquals(60, timer3.durationSeconds)
    }

    @Test
    fun testCommandParser_webResearchAndTeluguMovies() {
        val parser = NaturalLanguageCommandParser()

        val searchCmds = parser.parse("search for new telugu movies")
        assertTrue(searchCmds.isNotEmpty())
        val researchCmd = searchCmds.find { it is TaskCommand.WebResearch } as? TaskCommand.WebResearch
        assertNotNull("Should contain WebResearch command", researchCmd)
        assertTrue(researchCmd?.query?.contains("telugu movies") == true)
        assertEquals("movie_list", researchCmd?.extractType)

        val compoundCmds = parser.parse("open google and search for new telugu movies")
        assertTrue(compoundCmds.isNotEmpty())
        val researchCompound = compoundCmds.find { it is TaskCommand.WebResearch } as? TaskCommand.WebResearch
        assertNotNull("Compound command must extract WebResearch", researchCompound)
        assertTrue(researchCompound?.query?.contains("telugu movies") == true)
    }

    @Test
    fun testWebResearchEngine_extractsTeluguMovies() = kotlinx.coroutines.runBlocking {
        val engine = com.example.core.research.WebResearchEngine()
        val result = engine.conductResearch("new telugu movies", "movie_list")

        assertTrue("Extracted count must be greater than 8", result.extractedCount >= 8)
        assertTrue("Must include Telugu films", result.movies.any { it.title.contains("Devara") || it.title.contains("Pushpa") })
        assertNotNull("Summary must be populated", result.rawSummary)
    }

    @Test
    fun testTaskSynthesizer_timerAndWebResearchEncoding() {
        val synthesizer = com.example.core.recorder.TaskSynthesizer()
        val commands = listOf(
            TaskCommand.StartTimer(durationSeconds = 120, timerLabel = "Tea Timer"),
            TaskCommand.WebResearch(query = "new telugu movies", extractType = "movie_list")
        )

        val encoded = synthesizer.encodeCommands(commands)
        assertTrue(encoded.contains("START_TIMER|120|Tea Timer"))
        assertTrue(encoded.contains("WEB_RESEARCH|new telugu movies|movie_list"))

        val decoded = synthesizer.decodeCommands(encoded)
        assertEquals(2, decoded.size)
        assertTrue(decoded[0] is TaskCommand.StartTimer)
        val timerDecoded = decoded[0] as TaskCommand.StartTimer
        assertEquals(120, timerDecoded.durationSeconds)
        assertEquals("Tea Timer", timerDecoded.timerLabel)

        assertTrue(decoded[1] is TaskCommand.WebResearch)
        val researchDecoded = decoded[1] as TaskCommand.WebResearch
        assertEquals("new telugu movies", researchDecoded.query)
        assertEquals("movie_list", researchDecoded.extractType)
    }

    @Test
    fun testAutonomousRecoveryEngine_adaptsStrategyOnActuatorFailure() = kotlinx.coroutines.runBlocking {
        val recoveryEngine = com.example.core.engine.AutonomousRecoveryEngine()

        // 1. WiFi failure adaptation
        val wifiCmd = TaskCommand.ControlActuator(com.example.core.model.ActuatorType.WIFI_ON)
        val wifiRecovery = recoveryEngine.formulateRecoveryPlan(
            failedCommand = wifiCmd,
            failureReason = "SecurityException: CHANGE_WIFI_STATE restricted on API 29+",
            preSnapshot = null,
            durableStorage = null
        )
        assertNotNull(wifiRecovery)
        assertEquals("System Settings Panel Bypass", wifiRecovery.strategyName)
        assertTrue(wifiRecovery.alternativeCommands.any {
            it is TaskCommand.ControlActuator && it.actuatorType == com.example.core.model.ActuatorType.SETTINGS_WIFI
        })

        // 2. Bluetooth failure adaptation
        val btCmd = TaskCommand.ControlActuator(com.example.core.model.ActuatorType.BLUETOOTH_ON)
        val btRecovery = recoveryEngine.formulateRecoveryPlan(
            failedCommand = btCmd,
            failureReason = "BLUETOOTH_CONNECT permission missing",
            preSnapshot = null,
            durableStorage = null
        )
        assertNotNull(btRecovery)
        assertEquals("Bluetooth Intent Request Fallback", btRecovery.strategyName)
        assertTrue(btRecovery.alternativeCommands.any {
            it is TaskCommand.ControlActuator && it.actuatorType == com.example.core.model.ActuatorType.SETTINGS_BLUETOOTH
        })

        // 3. Click failure adaptation (Scroll viewport exploration)
        val clickCmd = TaskCommand.ClickElement(
            selector = TargetSelector(text = "Submit Order"),
            targetLabel = "Submit Order"
        )
        val clickRecovery = recoveryEngine.formulateRecoveryPlan(
            failedCommand = clickCmd,
            failureReason = "Target not visible on screen",
            preSnapshot = null,
            durableStorage = null
        )
        assertNotNull(clickRecovery)
        assertEquals("Scroll Exploration & Fallback Gesture", clickRecovery.strategyName)
        assertTrue(clickRecovery.alternativeCommands.any { it is TaskCommand.Scroll })
    }

    @Test
    fun testAgentSkill_modelCreationAndTriggerMatching() {
        val skill = com.example.core.model.AgentSkill(
            name = "Scrape Telugu Cinema",
            description = "Fetches trending Telugu releases with IMDB rating",
            triggerPhrases = listOf("telugu cinema", "new telugu movies", "tollywood releases"),
            category = "Web Intelligence",
            commands = listOf(
                TaskCommand.WebResearch("new telugu movies", extractType = "movie_list")
            )
        )

        assertEquals("Scrape Telugu Cinema", skill.name)
        assertTrue(skill.triggerPhrases.contains("new telugu movies"))
        assertEquals(1, skill.commands.size)

        // Test matching
        val userPrompt = "can you find new telugu movies please"
        val isMatched = skill.triggerPhrases.any { trigger -> userPrompt.contains(trigger, ignoreCase = true) }
        assertTrue("Skill should match trigger in prompt", isMatched)
    }

    @Test
    fun testEmergencyKillSwitch_volumeUpDoubleClickTimingAndAbort() {
        var killSwitchFired = false
        var recordedReason = ""
        com.example.service.LocalAgentAccessibilityService.onKillSwitchTriggered = { reason ->
            killSwitchFired = true
            recordedReason = reason
        }

        // Test timing logic: 2 presses within 400ms should trigger kill switch
        val press1Time = 1000L
        val press2Time = 1350L // 350ms diff <= 650ms
        val doubleClickWindowMs = 650L

        val diff = press2Time - press1Time
        val shouldTrigger = diff in 1..doubleClickWindowMs
        assertTrue("Double-press within window should trigger", shouldTrigger)

        // Dispatch simulated kill switch
        com.example.service.LocalAgentAccessibilityService.dispatchKillSwitch("Simulated double-click (<350ms)")
        assertTrue("Kill switch callback must be executed", killSwitchFired)
        assertTrue(recordedReason.contains("Simulated double-click"))
        assertTrue(com.example.service.LocalAgentAccessibilityService.killSwitchTriggeredCount.value >= 1)

        // Test timing logic: Slow presses (>700ms) should NOT trigger
        val slowPress1 = 1000L
        val slowPress2 = 1800L // 800ms diff > 650ms
        val slowDiff = slowPress2 - slowPress1
        val shouldTriggerSlow = slowDiff in 1..doubleClickWindowMs
        assertTrue("Slow presses exceeding 650ms must not trigger double click", !shouldTriggerSlow)
    }
}
