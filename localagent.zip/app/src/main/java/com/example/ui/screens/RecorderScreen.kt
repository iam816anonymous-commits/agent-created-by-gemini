package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MenuOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.model.ActionType
import com.example.core.model.ActuatorType
import com.example.core.model.RecordedInteraction
import com.example.core.model.ScrollDirection
import com.example.core.model.SynthesizedTask
import com.example.core.model.TargetSelector
import com.example.core.model.TaskCommand
import com.example.core.model.VerificationRule
import com.example.data.local.SkillEntity
import com.example.data.local.SynthesizedTaskEntity
import com.example.ui.AgentUiState
import com.example.ui.AgentViewModel
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.StatusFailure
import com.example.ui.theme.StatusRunning
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusTimeout
import com.example.ui.theme.StatusWarning

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecorderScreen(
    viewModel: AgentViewModel,
    uiState: AgentUiState,
    savedTasks: List<SynthesizedTaskEntity>,
    skills: List<SkillEntity> = emptyList()
) {
    var activeSubTab by remember { mutableStateOf(0) } // 0: Skill Adder & Library, 1: Visual Gesture Recorder
    val isRecording by viewModel.isRecording.collectAsStateWithLifecycle()
    val recordedEvents by viewModel.recordedEvents.collectAsStateWithLifecycle()
    val synthesizedPreview by viewModel.synthesizedTaskPreview.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section Segmented Selector
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (activeSubTab == 0) CyberCyanPrimary else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeSubTab = 0 }
                        .testTag("tab_skill_adder")
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = "Skills",
                            tint = if (activeSubTab == 0) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Skill Adder & Library",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (activeSubTab == 0) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (activeSubTab == 1) CyberCyanPrimary else Color.Transparent,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { activeSubTab = 1 }
                        .testTag("tab_visual_recorder")
                ) {
                    Row(
                        modifier = Modifier.padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Videocam,
                            contentDescription = "Recorder",
                            tint = if (activeSubTab == 1) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Visual Recorder",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = if (activeSubTab == 1) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (activeSubTab == 0) {
            // ==========================================
            // SUB-TAB 0: AGENT SKILL ADDER & BRAIN BODY
            // ==========================================
            SkillAdderSection(viewModel = viewModel, skills = skills)
        } else {
            // ==========================================
            // SUB-TAB 1: VISUAL GESTURE RECORDER
            // ==========================================
            VisualRecorderSection(
                viewModel = viewModel,
                uiState = uiState,
                isRecording = isRecording,
                recordedEvents = recordedEvents,
                synthesizedPreview = synthesizedPreview,
                savedTasks = savedTasks
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SkillAdderSection(
    viewModel: AgentViewModel,
    skills: List<SkillEntity>
) {
    var showAddForm by remember { mutableStateOf(false) }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }

    // Add Form State
    var newSkillName by remember { mutableStateOf("") }
    var newSkillDesc by remember { mutableStateOf("") }
    var newSkillTriggers by remember { mutableStateOf("") }
    var newSkillCategory by remember { mutableStateOf("Web Intelligence") }
    var newActionType by remember { mutableStateOf("WEB_RESEARCH") }
    var actionQueryOrParam by remember { mutableStateOf("new telugu movies") }
    var timerSeconds by remember { mutableStateOf("300") }

    // Hero Card
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberCyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .testTag("skill_adder_hero_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(StatusSuccess)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AGENT BRAIN & MOBILE BODY SKILLS",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyanPrimary,
                        letterSpacing = 1.2.sp
                    )
                }

                Surface(
                    color = CyberCyanPrimary.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${skills.size} active skills",
                        color = CyberCyanPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Add custom skills to LocalAgent. The agent brain interprets natural language trigger phrases and executes actions through its mobile body (actuators, Wi-Fi, Bluetooth, web scraping, timers, and app automation).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = { showAddForm = !showAddForm },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (showAddForm) MaterialTheme.colorScheme.surfaceVariant else CyberCyanPrimary,
                    contentColor = if (showAddForm) MaterialTheme.colorScheme.onSurface else Color.Black
                ),
                modifier = Modifier.fillMaxWidth().testTag("toggle_add_skill_button")
            ) {
                Icon(
                    imageVector = if (showAddForm) Icons.Default.Close else Icons.Default.Add,
                    contentDescription = "Toggle Add Skill Form"
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (showAddForm) "Close Skill Creator" else "+ Add New Skill to Agent Brain",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    // Expandable Skill Creator Form
    AnimatedVisibility(
        visible = showAddForm,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, CyberCyanPrimary, RoundedCornerShape(20.dp))
                .testTag("create_skill_form_card")
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "CREATE NEW AGENT SKILL",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = newSkillName,
                    onValueChange = { newSkillName = it },
                    label = { Text("Skill Name") },
                    placeholder = { Text("e.g. Scrape Telugu Movies") },
                    modifier = Modifier.fillMaxWidth().testTag("skill_name_field"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = newSkillDesc,
                    onValueChange = { newSkillDesc = it },
                    label = { Text("Description") },
                    placeholder = { Text("e.g. Scrapes latest released and trending Telugu films") },
                    modifier = Modifier.fillMaxWidth().testTag("skill_desc_field"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = newSkillTriggers,
                    onValueChange = { newSkillTriggers = it },
                    label = { Text("Trigger Phrases (comma-separated)") },
                    placeholder = { Text("e.g. search telugu movies, telugu movies, scrape movies") },
                    modifier = Modifier.fillMaxWidth().testTag("skill_triggers_field"),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "ACTION TYPE EXECUTED BY AGENT BODY",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.outline
                )
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val actions = listOf(
                        Pair("WEB_RESEARCH", "Web Research & Scraping"),
                        Pair("WIFI_ON", "Turn Wi-Fi ON"),
                        Pair("WIFI_OFF", "Turn Wi-Fi OFF"),
                        Pair("BLUETOOTH_ON", "Turn Bluetooth ON"),
                        Pair("BLUETOOTH_OFF", "Turn Bluetooth OFF"),
                        Pair("START_TIMER", "Start Countdown Timer"),
                        Pair("TORCH_TOGGLE", "Toggle Flashlight"),
                        Pair("HAPTIC_BURST", "Haptic Burst & Alert")
                    )
                    actions.forEach { (typeKey, label) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (newActionType == typeKey) CyberCyanPrimary else MaterialTheme.colorScheme.surface,
                            modifier = Modifier.clickable { newActionType = typeKey }
                        ) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (newActionType == typeKey) FontWeight.Bold else FontWeight.Normal,
                                color = if (newActionType == typeKey) Color.Black else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (newActionType == "WEB_RESEARCH") {
                    OutlinedTextField(
                        value = actionQueryOrParam,
                        onValueChange = { actionQueryOrParam = it },
                        label = { Text("Search / Scraping Query") },
                        placeholder = { Text("e.g. new telugu movies") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                } else if (newActionType == "START_TIMER") {
                    OutlinedTextField(
                        value = timerSeconds,
                        onValueChange = { timerSeconds = it },
                        label = { Text("Timer Duration (Seconds)") },
                        placeholder = { Text("300") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (newSkillName.isNotBlank() && newSkillTriggers.isNotBlank()) {
                            val triggers = newSkillTriggers.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                            val commands = when (newActionType) {
                                "WEB_RESEARCH" -> listOf(TaskCommand.WebResearch(query = actionQueryOrParam.ifBlank { "new telugu movies" }))
                                "WIFI_ON" -> listOf(TaskCommand.ControlActuator(ActuatorType.WIFI_ON))
                                "WIFI_OFF" -> listOf(TaskCommand.ControlActuator(ActuatorType.WIFI_OFF))
                                "BLUETOOTH_ON" -> listOf(TaskCommand.ControlActuator(ActuatorType.BLUETOOTH_ON))
                                "BLUETOOTH_OFF" -> listOf(TaskCommand.ControlActuator(ActuatorType.BLUETOOTH_OFF))
                                "START_TIMER" -> listOf(TaskCommand.StartTimer(durationSeconds = timerSeconds.toIntOrNull() ?: 300, timerLabel = newSkillName))
                                "TORCH_TOGGLE" -> listOf(TaskCommand.ControlActuator(ActuatorType.TORCH_TOGGLE))
                                "HAPTIC_BURST" -> listOf(
                                    TaskCommand.ControlActuator(ActuatorType.HAPTIC_BURST),
                                    TaskCommand.ControlActuator(ActuatorType.AUDIO_TONE)
                                )
                                else -> listOf(TaskCommand.WebResearch(query = actionQueryOrParam))
                            }
                            viewModel.addSkill(
                                name = newSkillName,
                                description = newSkillDesc.ifBlank { "Autonomous skill: $newSkillName" },
                                triggerPhrases = triggers,
                                category = newSkillCategory,
                                commands = commands
                            )
                            // Reset & close
                            newSkillName = ""
                            newSkillDesc = ""
                            newSkillTriggers = ""
                            showAddForm = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_skill_button")
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Save Skill")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Skill to Agent Brain", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // Category Filter Chips
    FlowRow(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val categories = listOf("ALL", "System & Hardware", "Web Intelligence", "Actuator & Routine", "App Control")
        categories.forEach { cat ->
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (selectedCategoryFilter == cat) CyberCyanPrimary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clickable { selectedCategoryFilter = cat }
            ) {
                Text(
                    text = cat,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedCategoryFilter == cat) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
    }

    // Skills List
    val filteredSkills = if (selectedCategoryFilter == "ALL") {
        skills
    } else {
        skills.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        filteredSkills.forEach { skillEntity ->
            SkillCardItem(
                skill = skillEntity,
                onRun = { viewModel.executeSkill(skillEntity) },
                onDelete = { viewModel.deleteSkill(skillEntity.id) }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SkillCardItem(
    skill: SkillEntity,
    onRun: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            .testTag("skill_card_${skill.name.replace(' ', '_').lowercase()}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    val icon = when {
                        skill.category.contains("Web", ignoreCase = true) || skill.name.contains("Movie", ignoreCase = true) -> Icons.Default.Language
                        skill.name.contains("Wi-Fi", ignoreCase = true) || skill.name.contains("Wifi", ignoreCase = true) -> Icons.Default.Wifi
                        skill.name.contains("Bluetooth", ignoreCase = true) -> Icons.Default.Bluetooth
                        skill.name.contains("Timer", ignoreCase = true) -> Icons.Default.HourglassTop
                        skill.name.contains("Flashlight", ignoreCase = true) || skill.name.contains("SOS", ignoreCase = true) -> Icons.Default.Vibration
                        else -> Icons.Default.AutoAwesome
                    }
                    Icon(
                        imageVector = icon,
                        contentDescription = skill.name,
                        tint = CyberCyanPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = skill.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (skill.isBuiltIn) CyberCyanPrimary.copy(alpha = 0.15f) else StatusSuccess.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = if (skill.isBuiltIn) "Built-In" else "Custom Brain Skill",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (skill.isBuiltIn) CyberCyanPrimary else StatusSuccess,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (!skill.isBuiltIn) {
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = skill.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Trigger Phrases
            Text(
                text = "TRIGGER PHRASES:",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(4.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                skill.triggerPhrases.split(",").forEach { trigger ->
                    if (trigger.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "\"${trigger.trim()}\"",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = CyberCyanPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onRun,
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyberCyanPrimary,
                    contentColor = Color.Black
                ),
                modifier = Modifier.fillMaxWidth().height(42.dp).testTag("run_skill_${skill.name.replace(' ', '_').lowercase()}")
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Run with Body", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Execute with Agent Mobile Body", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VisualRecorderSection(
    viewModel: AgentViewModel,
    uiState: AgentUiState,
    isRecording: Boolean,
    recordedEvents: List<RecordedInteraction>,
    synthesizedPreview: SynthesizedTask?,
    savedTasks: List<SynthesizedTaskEntity>
) {
    // Visual Recorder Command Center Card
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isRecording) StatusFailure else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                RoundedCornerShape(20.dp)
            )
            .testTag("recorder_control_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(if (isRecording) StatusFailure else MaterialTheme.colorScheme.outline)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRecording) "RECORDING ON-SCREEN INTERACTIONS" else "VISUAL RECORDER",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (isRecording) StatusFailure else CyberCyanPrimary,
                        letterSpacing = 1.2.sp
                    )
                }

                Surface(
                    color = (if (isRecording) StatusFailure else CyberCyanPrimary).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${recordedEvents.size} event(s)",
                        color = if (isRecording) StatusFailure else CyberCyanPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Record gestures, taps, text inputs, and drawer navigations. LocalAgent translates this visual sequence into an autonomous executable task.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = uiState.recordingTaskName,
                onValueChange = { viewModel.setRecordingTaskName(it) },
                label = { Text("Task Plan Name") },
                modifier = Modifier.fillMaxWidth().testTag("recorder_task_name_field"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyanPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Start / Stop Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (isRecording) {
                    Button(
                        onClick = { viewModel.stopVisualRecording() },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusFailure),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("stop_recording_button")
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop Recording")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop & Synthesize", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = { viewModel.startVisualRecording() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyanPrimary,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("start_recording_button")
                    ) {
                        Icon(Icons.Default.FiberManualRecord, contentDescription = "Start Recording", tint = Color.Red)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Recording", fontWeight = FontWeight.Bold)
                    }
                }

                if (recordedEvents.isNotEmpty() && !isRecording) {
                    OutlinedButton(
                        onClick = { viewModel.clearRecordedEvents() },
                        modifier = Modifier.height(48.dp).testTag("clear_recording_button")
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear")
                    }
                }
            }
        }
    }

    // Live Streamed Recorded Interactions Feed
    if (recordedEvents.isNotEmpty()) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Live Recorded Stream (${recordedEvents.size} gestures)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    recordedEvents.forEachIndexed { index, event ->
                        RecordedEventRow(index = index + 1, event = event)
                    }
                }
            }
        }
    }

    // Synthesized Autonomous Task Preview
    synthesizedPreview?.let { preview ->
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, StatusSuccess, RoundedCornerShape(20.dp))
                .testTag("synthesized_task_preview_card")
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "AUTONOMOUS TASK SYNTHESIS",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = StatusSuccess,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = preview.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    SmallBadge("${preview.commands.size} commands", StatusSuccess)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    preview.commands.forEachIndexed { idx, cmd ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${idx + 1}.",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.outline,
                                    modifier = Modifier.width(24.dp)
                                )
                                Text(
                                    text = cmd.displayName,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.saveSynthesizedTask() },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess, contentColor = Color.Black),
                        modifier = Modifier.weight(1f).height(46.dp).testTag("save_synthesized_task_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save Task")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Task", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.executeSynthesizedPreview() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black),
                        modifier = Modifier.weight(1f).height(46.dp).testTag("run_synthesized_task_button")
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Run Task")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Run Now", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Saved Synthesized Tasks in Room DB
    if (savedTasks.isNotEmpty()) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "Saved Synthesized Tasks (${savedTasks.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    savedTasks.forEach { taskEntity ->
                        SavedTaskRow(
                            task = taskEntity,
                            onRun = { viewModel.executeSynthesizedTask(taskEntity) },
                            onDelete = { viewModel.deleteSynthesizedTask(taskEntity.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SkillActionChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = CyberCyanPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun RecordedEventRow(index: Int, event: RecordedInteraction) {
    val (color, icon) = when (event.actionType) {
        ActionType.TAP -> Pair(CyberCyanPrimary, Icons.Default.TouchApp)
        ActionType.ENTER_TEXT -> Pair(StatusSuccess, Icons.Default.Edit)
        ActionType.SCROLL -> Pair(StatusWarning, Icons.Default.SwapVert)
        ActionType.SWIPE -> Pair(StatusWarning, Icons.Default.SwapVert)
        ActionType.OPEN_DRAWER -> Pair(StatusTimeout, Icons.Default.Menu)
        ActionType.CLOSE_DRAWER -> Pair(StatusTimeout, Icons.Default.MenuOpen)
        ActionType.ACTUATOR -> Pair(CyberCyanPrimary, Icons.Default.Vibration)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$index",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.outline,
            modifier = Modifier.width(22.dp)
        )
        Icon(imageVector = icon, contentDescription = event.actionType.name, tint = color, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = event.targetLabel, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            if (event.delayFromPreviousMs > 0) {
                Text(text = "+${event.delayFromPreviousMs}ms", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
            }
        }
        SmallBadge(event.actionType.name, color)
    }
}

@Composable
fun SavedTaskRow(
    task: SynthesizedTaskEntity,
    onRun: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = task.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
            Text(
                text = "${task.commandCount} autonomous commands | ${task.rawInteractionsCount} interactions",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onRun) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Run Task", tint = StatusSuccess)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Task", tint = MaterialTheme.colorScheme.outline)
            }
        }
    }
}
