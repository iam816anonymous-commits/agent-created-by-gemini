package com.example.ui.screens

import android.os.Build
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SignalWifiOff
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.core.model.OfflineDiagnosticResult
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.DeviceCapabilities
import com.example.ui.AgentUiState
import com.example.ui.AgentViewModel
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.StatusFailure
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning

@Composable
fun DeviceScreen(
    viewModel: AgentViewModel,
    uiState: AgentUiState,
    capabilities: DeviceCapabilities,
    storageMetrics: Pair<Long, Long>
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Device Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SYSTEM & CAPABILITY MATRIX",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = CyberCyanPrimary,
                letterSpacing = 1.2.sp
            )

            IconButton(
                onClick = { viewModel.refreshCapabilities() },
                modifier = Modifier.testTag("refresh_device_button")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh Matrix", tint = CyberCyanPrimary)
            }
        }

        // Hardware Profile Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Devices,
                        contentDescription = "Device",
                        tint = CyberCyanPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Target Hardware Environment",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                val totalRamGb = String.format("%.1f", capabilities.totalRamBytes / (1024.0 * 1024.0 * 1024.0))
                val availRamGb = String.format("%.1f", capabilities.availableRamBytes / (1024.0 * 1024.0 * 1024.0))
                val totalStorageGb = String.format("%.1f", storageMetrics.first / (1024.0 * 1024.0 * 1024.0))
                val freeStorageGb = String.format("%.1f", storageMetrics.second / (1024.0 * 1024.0 * 1024.0))

                HardwareMetricRow("Device Model", "${capabilities.manufacturer} ${capabilities.model} (TECNO Profile)")
                HardwareMetricRow("OS Architecture", "Android ${capabilities.androidVersion} (API ${capabilities.sdkInt})")
                HardwareMetricRow("Physical RAM", "$availRamGb GB available / $totalRamGb GB total")
                HardwareMetricRow("Internal Storage", "$freeStorageGb GB free / $totalStorageGb GB capacity")
                HardwareMetricRow("Minimum API Target", "Android 8.1 (API 27) Supported")
            }
        }

        // 100% Offline-First Autonomous Architecture Card
        val offlineDiag by viewModel.offlineDiagnostics.collectAsState()
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .testTag("offline_architecture_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SignalWifiOff,
                            contentDescription = "Offline Architecture",
                            tint = CyberCyanPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Offline Autonomous Engine",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        color = StatusSuccess.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusSuccess.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "100% ON-DEVICE",
                            color = StatusSuccess,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "How LocalAgent Operates Offline:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = CyberCyanPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "LocalAgent is engineered to run entirely on your phone with ZERO network calls, zero external LLM API tokens, and zero telemetry. It operates reliably in Airplane Mode, in remote environments, and in privacy-critical workflows.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // The 5 Core Offline Pillars
                OfflinePillarRow("1. Local NLP Intent Normalizer", "Rule & regex based parsing runs on-device in <5ms without cloud servers.")
                OfflinePillarRow("2. Android Accessibility Service", "Reads live UI trees directly from OS memory via AccessibilityNodeInfo.")
                OfflinePillarRow("3. Deterministic Target Resolver", "Fuzzy text, spatial coordinates, and accessibility roles resolved locally.")
                OfflinePillarRow("4. Action & Gesture Dispatcher", "Performs clicks, text entry, and multi-touch swipes via local gesture builder.")
                OfflinePillarRow("5. Outcome Verifier & Room Database", "Post-action screens verified independently; history stored in local SQLite.")

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Offline Self-Test Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Offline Subsystem Self-Check",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (offlineDiag.executedAt > 0) offlineDiag.summary else "Test all 5 offline modules in-memory now.",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (offlineDiag.allPassed) StatusSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { viewModel.runOfflineSelfCheck() },
                        enabled = !offlineDiag.isRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("run_offline_check_button")
                    ) {
                        if (offlineDiag.isRunning) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.Black, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.TaskAlt, contentDescription = "Test", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Engines", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (offlineDiag.executedAt > 0) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            DiagnosticModuleResultRow("Rule-Based Command Parser", offlineDiag.parserPassed, offlineDiag.parserLatencyMs)
                            DiagnosticModuleResultRow("Target Resolver (Spatial & Text)", offlineDiag.resolverPassed, offlineDiag.resolverLatencyMs)
                            DiagnosticModuleResultRow("Action Dispatcher & Gesture Math", offlineDiag.executorPassed, offlineDiag.executorLatencyMs)
                            DiagnosticModuleResultRow("Independent Outcome Verifier", offlineDiag.verifierPassed, offlineDiag.verifierLatencyMs)
                            DiagnosticModuleResultRow("Room SQLite Local Database", offlineDiag.storagePassed, offlineDiag.storageLatencyMs)
                        }
                    }
                }
            }
        }

        // Permissions & Services Diagnostics Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Permission & Service Diagnostic Matrix",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                PermissionRow(
                    title = "Accessibility Automation Service",
                    description = "Inspects live UI trees and performs touches",
                    isGranted = capabilities.isAccessibilityEnabled,
                    onConfigure = { viewModel.openAccessibilitySettings(context) }
                )

                PermissionRow(
                    title = "System Overlay (Draw Over Other Apps)",
                    description = "Required for overlay indicators and floating agent controls",
                    isGranted = capabilities.canDrawOverlays,
                    onConfigure = { viewModel.openOverlaySettings(context) }
                )

                PermissionRow(
                    title = "Battery Optimization Exemption",
                    description = "Prevents TECNO HiOS from killing background automation",
                    isGranted = capabilities.isIgnoringBatteryOptimizations,
                    onConfigure = { viewModel.openBatterySettings(context) }
                )
            }
        }

        // Controllable Hardware & Actuator Deck Card (Wi-Fi, Bluetooth, Haptics, Torch, Audio)
        val isWifiEnabled by viewModel.isWifiEnabled.collectAsState()
        val isBluetoothEnabled by viewModel.isBluetoothEnabled.collectAsState()
        val isTorchOn by viewModel.actuatorController.isTorchOn.collectAsState()
        val liveSensors by viewModel.liveSensors.collectAsState()

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCyanPrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .testTag("hardware_control_deck_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Vibration, contentDescription = null, tint = CyberCyanPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Hardware Control & Actuator Deck",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    SmallBadge("FULL CONTROL", CyberCyanPrimary)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Direct on-device actuation for Wi-Fi, Bluetooth, tactile haptics, camera torch, and audio streams with dynamic status reflection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Wi-Fi Hardware Control Row
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Wifi,
                                contentDescription = "Wi-Fi",
                                tint = if (isWifiEnabled) StatusSuccess else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Wi-Fi Hardware Toggle",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isWifiEnabled) "Hardware State: ACTIVE / CONNECTED" else "Hardware State: DISABLED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isWifiEnabled) StatusSuccess else MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { viewModel.launchHardwareSetting(android.provider.Settings.ACTION_WIFI_SETTINGS) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text("Panel", fontSize = 10.sp)
                            }
                            Switch(
                                checked = isWifiEnabled,
                                onCheckedChange = { viewModel.setWifi(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = CyberCyanPrimary
                                ),
                                modifier = Modifier.testTag("wifi_hardware_switch")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Bluetooth Hardware Control Row
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bluetooth,
                                contentDescription = "Bluetooth",
                                tint = if (isBluetoothEnabled) CyberCyanPrimary else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Bluetooth Adapter Toggle",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isBluetoothEnabled) "Adapter State: POWERED ON" else "Adapter State: DISABLED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isBluetoothEnabled) CyberCyanPrimary else MaterialTheme.colorScheme.outline
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedButton(
                                onClick = { viewModel.launchHardwareSetting(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS) },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text("Panel", fontSize = 10.sp)
                            }
                            Switch(
                                checked = isBluetoothEnabled,
                                onCheckedChange = { viewModel.setBluetooth(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = CyberCyanPrimary
                                ),
                                modifier = Modifier.testTag("bluetooth_hardware_switch")
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tactile & Sensory Actuator Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.triggerHapticPulse() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Vibration, contentDescription = null, modifier = Modifier.size(16.dp), tint = CyberCyanPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Haptic Pulse", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.triggerHapticBurst() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Vibration, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusWarning)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Double Burst", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.toggleFlashlight() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isTorchOn) CyberCyanPrimary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isTorchOn) Color.Black else MaterialTheme.colorScheme.onSurface
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.FlashlightOn, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isTorchOn) "Torch: ON" else "Torch: OFF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.triggerAudioTone() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusSuccess)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Audio Chime", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Hardware System Setting Triggers
                Text("Hardware System Setting Launchers", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PresetChip("Wi-Fi") { viewModel.launchHardwareSetting(android.provider.Settings.ACTION_WIFI_SETTINGS) }
                    PresetChip("Bluetooth") { viewModel.launchHardwareSetting(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS) }
                    PresetChip("Airplane") { viewModel.launchHardwareSetting(android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS) }
                    PresetChip("Display") { viewModel.launchHardwareSetting(android.provider.Settings.ACTION_DISPLAY_SETTINGS) }
                }
            }
        }

        // Live Sensors Telemetry Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                .testTag("sensors_telemetry_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Sensors, contentDescription = "Sensors", tint = CyberCyanPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Live On-Device Sensor Telemetry",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    SmallBadge("REAL-TIME", StatusSuccess)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Continuous physical hardware telemetry captured by the device's SensorManager.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                val accelStr = "X: ${String.format("%.2f", liveSensors.accelerometerX)} | Y: ${String.format("%.2f", liveSensors.accelerometerY)} | Z: ${String.format("%.2f", liveSensors.accelerometerZ)} m/s²"
                HardwareMetricRow("3-Axis Accelerometer", accelStr)
                HardwareMetricRow("Ambient Light Sensor", "${String.format("%.1f", liveSensors.ambientLightLux)} Lux")
                val proxStr = "${String.format("%.1f", liveSensors.proximityDistanceCm)} cm (${if (liveSensors.isProximityNear) "NEAR" else "FAR"})"
                HardwareMetricRow("Proximity Sensor", proxStr)
                HardwareMetricRow("Barometric Pressure", "${String.format("%.2f", liveSensors.pressureHpa)} hPa")
            }
        }

        // Autonomous Strategy Shifting & Self-Healing Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, StatusWarning.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .testTag("self_healing_recovery_card")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = StatusWarning)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Autonomous Awareness & Strategy Shift",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    SmallBadge("SELF-HEALING", StatusWarning)
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "The agent is fully aware of its actions and system feedback. If any hardware actuator or UI automation fails, it autonomously changes strategy using on-device heuristics and web/AI strategy intelligence:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                OfflinePillarRow("• OS Restriction Bypass", "If direct Wi-Fi/Bluetooth toggle is blocked on Android 10+ (API 29+), adapts strategy to invoke Settings Panel / Authorization Intents.")
                OfflinePillarRow("• Viewport & Fuzzy Recovery", "If a UI button is off-screen, auto-generates scroll exploration and fuzzy text match algorithms.")
                OfflinePillarRow("• Web/AI Strategy Synthesis", "Consults web intelligence search models (ChatGPT/Gemini strategy guides) to learn alternative interaction routes.")
            }
        }

        // Durable Memory & Learning Survival Card
        val durableStatus by viewModel.durableBackupStatus.collectAsState()
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, StatusSuccess.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = StatusSuccess)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Durable Learning (Survives Uninstall)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    SmallBadge(if (durableStatus.exists) "PRESERVED" else "READY", StatusSuccess)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = durableStatus.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Storage target: ${durableStatus.filePath.substringAfterLast("/")}",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.outline
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.exportDurableMemory() },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export / Sync Now", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.importDurableMemory() },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Restore Memory", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Execution & Resource Limits Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Resource Limits & Execution Tuning",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Step Timeout Slider
                Text(
                    text = "Step Timeout: ${uiState.stepTimeoutSec.toInt()}s",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Maximum duration per autonomous action before bounded guard aborts.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = uiState.stepTimeoutSec,
                    onValueChange = { viewModel.setStepTimeoutSec(it) },
                    valueRange = 2f..15f,
                    steps = 12,
                    colors = SliderDefaults.colors(thumbColor = CyberCyanPrimary, activeTrackColor = CyberCyanPrimary)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Max Retries
                Text(
                    text = "Max Step Retries: ${uiState.maxRetries}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = uiState.maxRetries.toFloat(),
                    onValueChange = { viewModel.setMaxRetries(it.toInt()) },
                    valueRange = 0f..5f,
                    steps = 4,
                    colors = SliderDefaults.colors(thumbColor = CyberCyanPrimary, activeTrackColor = CyberCyanPrimary)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Target Calculator Package selector
                Text(
                    text = "Target Calculator Package",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Configures package for Calculator launch and node resolution.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = uiState.targetCalculatorPackage,
                    onValueChange = { viewModel.setTargetCalculatorPackage(it) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PresetChip("com.google.android.calculator") { viewModel.setTargetCalculatorPackage(it) }
                    PresetChip("com.transsion.calculator") { viewModel.setTargetCalculatorPackage(it) }
                }
            }
        }
    }
}

@Composable
fun HardwareMetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun PermissionRow(
    title: String,
    description: String,
    isGranted: Boolean,
    onConfigure: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(text = description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (isGranted) {
            Surface(
                color = StatusSuccess.copy(alpha = 0.15f),
                shape = RoundedCornerShape(6.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, StatusSuccess.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Active", tint = StatusSuccess, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ACTIVE", color = StatusSuccess, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Button(
                onClick = onConfigure,
                colors = ButtonDefaults.buttonColors(containerColor = StatusWarning, contentColor = Color.Black),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.height(34.dp)
            ) {
                Text("Enable", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun OfflinePillarRow(title: String, explanation: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = explanation,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun DiagnosticModuleResultRow(name: String, isPassed: Boolean, latencyMs: Long) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (isPassed) Icons.Default.Check else Icons.Default.Close,
                contentDescription = null,
                tint = if (isPassed) StatusSuccess else StatusFailure,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = name,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Text(
            text = if (isPassed) "PASSED (${latencyMs}ms)" else "FAILED",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = if (isPassed) StatusSuccess else StatusFailure
        )
    }
}
