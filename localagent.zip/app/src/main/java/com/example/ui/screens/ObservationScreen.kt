package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.AgentEngineState
import com.example.core.model.ConsoleLogLevel
import com.example.core.model.ExternalObservationData
import com.example.core.model.LiveConsoleEntry
import com.example.core.model.SnapshotComparisonDiff
import com.example.core.model.UiNode
import com.example.core.model.UiSnapshot
import com.example.ui.AgentUiState
import com.example.ui.AgentViewModel
import com.example.ui.ObservationSubTab
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.StatusFailure
import com.example.ui.theme.StatusRunning
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning

@Composable
fun ObservationScreen(
    viewModel: AgentViewModel,
    uiState: AgentUiState,
    engineState: AgentEngineState
) {
    val diff by viewModel.activeComparisonDiff.collectAsState()
    val consoleEntries by viewModel.liveConsoleEntries.collectAsState()
    val externalObs by viewModel.externalObservation.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        // Sub-tabs row
        val subTabs = ObservationSubTab.values()
        ScrollableTabRow(
            selectedTabIndex = uiState.observationSubTab.ordinal,
            edgePadding = 0.dp,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = CyberCyanPrimary,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
        ) {
            subTabs.forEach { tab ->
                Tab(
                    selected = uiState.observationSubTab == tab,
                    onClick = { viewModel.setObservationSubTab(tab) },
                    text = {
                        Text(
                            text = tab.label,
                            fontSize = 12.sp,
                            fontWeight = if (uiState.observationSubTab == tab) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        when (uiState.observationSubTab) {
            ObservationSubTab.DUAL_TREE_DIFF -> {
                DualViewTreesDiffView(
                    diff = diff,
                    viewModel = viewModel
                )
            }
            ObservationSubTab.SINGLE_INSPECTOR -> {
                SingleNodeInspectorView(
                    viewModel = viewModel,
                    uiState = uiState,
                    engineState = engineState
                )
            }
            ObservationSubTab.LIVE_CONSOLE -> {
                LiveConsoleView(
                    consoleEntries = consoleEntries,
                    filter = uiState.liveConsoleFilter,
                    onFilterChange = { viewModel.setLiveConsoleFilter(it) },
                    onClear = { viewModel.clearLiveConsole() }
                )
            }
            ObservationSubTab.EXTERNAL_OBSERVATION -> {
                ExternalObservationView(
                    data = externalObs,
                    onRefresh = { viewModel.refreshExternalObservation() }
                )
            }
        }
    }
}

@Composable
fun DualViewTreesDiffView(
    diff: SnapshotComparisonDiff,
    viewModel: AgentViewModel
) {
    var diffFilterMode by remember { mutableStateOf("ALL") } // ALL, MUTATED, ADDED, REMOVED, SIDE_BY_SIDE

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Summary & Test Controls Card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCyanPrimary.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CompareArrows, contentDescription = null, tint = CyberCyanPrimary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "TWO VIEW TREES COMPARISON",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = CyberCyanPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { viewModel.generateSamplePrePostComparison() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("test_diff_sample_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sample Diff", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = diff.summary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Node Count Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DiffMetricChip("Mutated", "~${diff.mutatedNodes.size}", CyberCyanPrimary)
                        DiffMetricChip("Added", "+${diff.addedCount}", StatusSuccess)
                        DiffMetricChip("Removed", "-${diff.removedCount}", StatusFailure)
                        DiffMetricChip("Unchanged", "=${diff.unchangedCount}", MaterialTheme.colorScheme.outline)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Pre: ${diff.preSnapshot?.packageName ?: "None"} (${diff.preSnapshot?.totalNodeCount ?: 0} nodes)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Post: ${diff.postSnapshot?.packageName ?: "None"} (${diff.postSnapshot?.totalNodeCount ?: 0} nodes)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Filter chips for diff viewing
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "ALL" to "All Differences",
                    "MUTATED" to "Mutated (${diff.mutatedNodes.size})",
                    "ADDED" to "Added (${diff.addedCount})",
                    "REMOVED" to "Removed (${diff.removedCount})",
                    "SIDE_BY_SIDE" to "2 View Trees Side-by-Side"
                ).forEach { (key, label) ->
                    FilterChip(
                        selected = diffFilterMode == key,
                        onClick = { diffFilterMode = key },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberCyanPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = CyberCyanPrimary
                        )
                    )
                }
            }
        }

        if (diffFilterMode == "SIDE_BY_SIDE") {
            item {
                DualTreesSideBySideCard(diff = diff)
            }
        } else {
            // Mutated nodes list
            if (diffFilterMode in listOf("ALL", "MUTATED") && diff.mutatedNodes.isNotEmpty()) {
                item {
                    Text(
                        text = "MUTATED NODES (BEFORE -> AFTER)",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyanPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(diff.mutatedNodes) { (preNode, postNode) ->
                    MutatedNodeCard(pre = preNode, post = postNode)
                }
            }

            // Added nodes list
            if (diffFilterMode in listOf("ALL", "ADDED") && diff.addedNodes.isNotEmpty()) {
                item {
                    Text(
                        text = "ADDED NODES (APPEARED AFTER ACTION)",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = StatusSuccess,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(diff.addedNodes) { node ->
                    AddedOrRemovedNodeCard(node = node, isAdded = true)
                }
            }

            // Removed nodes list
            if (diffFilterMode in listOf("ALL", "REMOVED") && diff.removedNodes.isNotEmpty()) {
                item {
                    Text(
                        text = "REMOVED NODES (DISAPPEARED AFTER ACTION)",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = StatusFailure,
                        fontWeight = FontWeight.Bold
                    )
                }
                items(diff.removedNodes) { node ->
                    AddedOrRemovedNodeCard(node = node, isAdded = false)
                }
            }
        }
    }
}

@Composable
fun MutatedNodeCard(pre: UiNode, post: UiNode) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberCyanPrimary.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            val label = post.resourceId?.substringAfterLast("/") ?: post.className.substringAfterLast(".")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanPrimary
                )
                SmallBadge("MUTATED", CyberCyanPrimary)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Before vs After Text Comparison
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text("BEFORE ACTION", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                    Text(
                        text = if (pre.text.isNullOrEmpty()) "(empty)" else "'${pre.text}'",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text("Desc: ${pre.contentDescription ?: "(none)"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text("AFTER ACTION", style = MaterialTheme.typography.labelSmall, color = CyberCyanPrimary)
                    Text(
                        text = if (post.text.isNullOrEmpty()) "(empty)" else "'${post.text}'",
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyanPrimary
                    )
                    Text("Desc: ${post.contentDescription ?: "(none)"}", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "ID: ${post.resourceId ?: "none"} | Class: ${post.className.substringAfterLast(".")}",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun AddedOrRemovedNodeCard(node: UiNode, isAdded: Boolean) {
    val color = if (isAdded) StatusSuccess else StatusFailure
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(10.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val label = node.text ?: node.contentDescription ?: node.resourceId?.substringAfterLast("/") ?: node.className.substringAfterLast(".")
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = color
                )
                SmallBadge(if (isAdded) "+ ADDED" else "- REMOVED", color)
            }
            Text(
                text = "Class: ${node.className.substringAfterLast(".")} | Bounds: (${node.bounds.left}, ${node.bounds.top}) - (${node.bounds.right}, ${node.bounds.bottom})",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.outline
            )
        }
    }
}

@Composable
fun DualTreesSideBySideCard(diff: SnapshotComparisonDiff) {
    val preNodes = diff.preSnapshot?.allNodes ?: emptyList()
    val postNodes = diff.postSnapshot?.allNodes ?: emptyList()

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "2 VIEWS TREES (PRE-ACTION vs POST-ACTION)",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = CyberCyanPrimary,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                // Column 1: Pre-Action Tree
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        color = MaterialTheme.colorScheme.background,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "TREE A: PRE-ACTION (${preNodes.size})",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.padding(6.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    preNodes.take(15).forEach { node ->
                        TreeMiniNode(node = node, highlight = false)
                    }
                }

                // Column 2: Post-Action Tree
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        color = CyberCyanPrimary.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "TREE B: POST-ACTION (${postNodes.size})",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyanPrimary,
                            modifier = Modifier.padding(6.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    postNodes.take(15).forEach { node ->
                        val isMutated = diff.mutatedNodes.any { it.second.id == node.id }
                        val isAdded = diff.addedNodes.any { it.id == node.id }
                        TreeMiniNode(node = node, highlight = isMutated || isAdded)
                    }
                }
            }
        }
    }
}

@Composable
fun TreeMiniNode(node: UiNode, highlight: Boolean) {
    val label = node.text ?: node.contentDescription ?: node.resourceId?.substringAfterLast("/") ?: node.className.substringAfterLast(".")
    Surface(
        color = if (highlight) CyberCyanPrimary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Column(modifier = Modifier.padding(4.dp)) {
            Text(
                text = "${"  ".repeat(node.depth.coerceAtMost(3))}$label",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
                color = if (highlight) CyberCyanPrimary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

@Composable
fun SingleNodeInspectorView(
    viewModel: AgentViewModel,
    uiState: AgentUiState,
    engineState: AgentEngineState
) {
    val snapshot: UiSnapshot? = engineState.latestObservation ?: engineState.postSnapshot ?: engineState.preSnapshot
    val allNodes = snapshot?.allNodes ?: emptyList()

    val filteredNodes = allNodes.filter { node ->
        val query = uiState.inspectionFilterText.trim().lowercase()
        val matchesQuery = query.isEmpty() ||
                node.text?.lowercase()?.contains(query) == true ||
                node.contentDescription?.lowercase()?.contains(query) == true ||
                node.resourceId?.lowercase()?.contains(query) == true ||
                node.className.lowercase().contains(query)

        val matchesClickable = !uiState.inspectionClickableOnly || node.isClickable
        matchesQuery && matchesClickable
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Snapshot header card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ACTIVE OBSERVATION",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = CyberCyanPrimary,
                            letterSpacing = 1.2.sp
                        )
                        Text(
                            text = snapshot?.packageName ?: "No Active Window",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { viewModel.captureFreshObservation() },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("refresh_snapshot_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Capture", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    MetadataBadge(label = "Nodes", value = "${allNodes.size}")
                    MetadataBadge(label = "Source", value = if (snapshot?.isLive == true) "Live Service" else "Diagnostic")
                    MetadataBadge(label = "Timestamp", value = if (snapshot != null) formatTime(snapshot.timestampMs) else "N/A")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search & Filter controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = uiState.inspectionFilterText,
                onValueChange = { viewModel.setInspectionFilter(it) },
                placeholder = { Text("Filter by text, id, or class...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = CyberCyanPrimary) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("filter_nodes_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyanPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                ),
                singleLine = true
            )

            FilterChip(
                selected = uiState.inspectionClickableOnly,
                onClick = { viewModel.toggleInspectionClickableOnly() },
                label = { Text("Clickable") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyberCyanPrimary.copy(alpha = 0.2f),
                    selectedLabelColor = CyberCyanPrimary
                ),
                modifier = Modifier.testTag("filter_clickable_chip")
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Showing ${filteredNodes.size} of ${allNodes.size} nodes",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(6.dp))

        if (filteredNodes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Info, contentDescription = "Empty", tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(40.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (snapshot == null) "No observation captured yet" else "No nodes match filter",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredNodes, key = { it.id }) { node ->
                    UiNodeCard(
                        node = node,
                        isSelected = uiState.selectedNodeForDetail?.id == node.id,
                        onClick = { viewModel.setSelectedNodeForDetail(if (uiState.selectedNodeForDetail?.id == node.id) null else node) }
                    )
                }
            }
        }
    }
}

@Composable
fun LiveConsoleView(
    consoleEntries: List<LiveConsoleEntry>,
    filter: String,
    onFilterChange: (String) -> Unit,
    onClear: () -> Unit
) {
    val filteredEntries = consoleEntries.filter { entry ->
        when (filter) {
            "ALL" -> true
            "OBSERVATION" -> entry.level == ConsoleLogLevel.OBSERVATION
            "ACTUATOR" -> entry.level == ConsoleLogLevel.ACTUATOR
            "ACTION" -> entry.level == ConsoleLogLevel.ACTION
            "WARNING" -> entry.level == ConsoleLogLevel.WARNING || entry.level == ConsoleLogLevel.ERROR
            else -> true
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Terminal, contentDescription = null, tint = CyberCyanPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LIVE CONSOLE STREAM (${consoleEntries.size})",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanPrimary
                )
            }

            IconButton(onClick = onClear) {
                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.outline)
            }
        }

        // Filter chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "OBSERVATION", "ACTUATOR", "ACTION", "WARNING").forEach { f ->
                FilterChip(
                    selected = filter == f,
                    onClick = { onFilterChange(f) },
                    label = { Text(f, fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberCyanPrimary.copy(alpha = 0.2f),
                        selectedLabelColor = CyberCyanPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (filteredEntries.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "No console events logged yet",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.outline
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredEntries, key = { it.id }) { entry ->
                    LiveConsoleEntryRow(entry = entry)
                }
            }
        }
    }
}

@Composable
fun LiveConsoleEntryRow(entry: LiveConsoleEntry) {
    val badgeColor = when (entry.level) {
        ConsoleLogLevel.ACTUATOR -> CyberCyanPrimary
        ConsoleLogLevel.ACTION -> StatusRunning
        ConsoleLogLevel.OBSERVATION -> StatusSuccess
        ConsoleLogLevel.WARNING -> StatusWarning
        ConsoleLogLevel.ERROR -> StatusFailure
        else -> MaterialTheme.colorScheme.outline
    }

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SmallBadge(entry.tag, badgeColor)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = formatTime(entry.timestampMs),
                        style = MaterialTheme.typography.bodySmall,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
                SmallBadge(entry.level.name, badgeColor)
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = entry.message,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )

            if (!entry.extraData.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = entry.extraData,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun ExternalObservationView(
    data: ExternalObservationData,
    onRefresh: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "EXTERNAL HARDWARE & RUNTIME TELEMETRY",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = CyberCyanPrimary,
                fontWeight = FontWeight.Bold
            )

            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = CyberCyanPrimary)
            }
        }

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, CyberCyanPrimary.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Devices, contentDescription = null, tint = CyberCyanPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Window & Surface Observation",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                TelemetryRow("Foreground Package", data.foregroundPackage)
                TelemetryRow("Window Title", data.windowTitle)
                TelemetryRow("Display Frame", data.displayMetrics)
                TelemetryRow("App Memory Footprint", "${data.memoryUsageMb} MB Private Heap")
            }
        }

        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (data.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                        contentDescription = null,
                        tint = if (data.batteryPct > 20) StatusSuccess else StatusWarning
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Power & Thermal Environment",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                TelemetryRow("Battery Level", "${data.batteryPct}% (${if (data.isCharging) "Charging" else "Discharging"})")
                TelemetryRow("Thermal State", data.thermalState)
                TelemetryRow("Network Boundary", data.networkMode)
                TelemetryRow("Observation Updated", formatTime(data.timestampMs))
            }
        }
    }
}

@Composable
fun TelemetryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun DiffMetricChip(label: String, value: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Text(text = label, fontSize = 9.sp, color = color, fontWeight = FontWeight.Bold)
            Text(text = value, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Black, color = color)
        }
    }
}

@Composable
fun UiNodeCard(
    node: UiNode,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(
                1.dp,
                if (isSelected) CyberCyanPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
                RoundedCornerShape(12.dp)
            )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val label = node.text ?: node.contentDescription ?: node.resourceId?.substringAfterLast("/") ?: node.className.substringAfterLast(".")
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (node.text != null) CyberCyanPrimary else MaterialTheme.colorScheme.onSurface
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (node.isClickable) {
                        SmallBadge("Clickable", StatusSuccess)
                    }
                    if (node.isEditable) {
                        SmallBadge("Editable", CyberCyanPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            if (!node.resourceId.isNullOrEmpty()) {
                Text(
                    text = "ID: ${node.resourceId}",
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(
                text = "Bounds: (${node.bounds.left}, ${node.bounds.top}) - (${node.bounds.right}, ${node.bounds.bottom}) | Center: (${node.bounds.centerX}, ${node.bounds.centerY})",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.outline
            )

            if (isSelected) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Text("Class: ${node.className}", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    node.text?.let { Text("Text: '$it'", fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    node.contentDescription?.let { Text("ContentDesc: '$it'", fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    Text("Visible: ${node.isVisibleToUser} | Enabled: ${node.isEnabled} | Focused: ${node.isFocused}", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun SmallBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(4.dp)
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun MetadataBadge(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
    }
}

private fun formatTime(timeMs: Long): String {
    val formatter = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.getDefault())
    return formatter.format(java.util.Date(timeMs))
}
