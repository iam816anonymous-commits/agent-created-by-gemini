package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.SnapshotDiffer
import com.example.core.engine.SnapshotStorage
import com.example.core.model.SnapshotComparisonDiff
import com.example.core.model.UiNode
import com.example.core.model.UiSnapshot
import com.example.data.local.StepRecordEntity
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.StatusFailure
import com.example.ui.theme.StatusInconclusive
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusTimeout
import com.example.ui.theme.StatusWarning

enum class SnapshotViewMode {
    BEFORE,
    AFTER,
    COMPARISON_DIFF
}

enum class ActionCapabilityFilter(val label: String) {
    ALL("All Elements"),
    CLICKABLE("Clickable (Taps)"),
    LONG_CLICKABLE("Long Clickable (Hold)"),
    SCROLLABLE("Scrollable (Up/Down)"),
    EDITABLE("Editable (Text)")
}

@Composable
fun SnapshotGalleryView(
    steps: List<StepRecordEntity>,
    onCloseGallery: () -> Unit
) {
    var selectedStepIndex by remember { mutableIntStateOf(0) }
    var viewMode by remember { mutableStateOf(SnapshotViewMode.BEFORE) }
    var capabilityFilter by remember { mutableStateOf(ActionCapabilityFilter.ALL) }
    var selectedNode by remember { mutableStateOf<UiNode?>(null) }

    if (steps.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text("No recorded steps found for this execution.")
        }
        return
    }

    val activeStep = steps.getOrNull(selectedStepIndex) ?: steps.first()
    val (preSnapshot, postSnapshot) = remember(activeStep.id) {
        SnapshotStorage.getStepSnapshots(activeStep.preSnapshotId, activeStep.postSnapshotId, activeStep.commandSummary)
    }

    val diff: SnapshotComparisonDiff = remember(preSnapshot, postSnapshot) {
        SnapshotDiffer.computeDiff(preSnapshot, postSnapshot)
    }

    val activeSnapshot = when (viewMode) {
        SnapshotViewMode.BEFORE -> preSnapshot
        SnapshotViewMode.AFTER -> postSnapshot
        SnapshotViewMode.COMPARISON_DIFF -> postSnapshot
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(12.dp)
            .testTag("snapshot_gallery_view")
    ) {
        // Gallery Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onCloseGallery, modifier = Modifier.testTag("close_gallery_button")) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = CyberCyanPrimary)
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "SNAPSHOT GALLERY & TREE DIFF",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyanPrimary,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "Step ${activeStep.stepIndex}: ${activeStep.commandSummary}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }

            SmallBadge(activeStep.status, if (activeStep.status == "SUCCESS") StatusSuccess else StatusFailure)
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Step Navigation Bar
        if (steps.size > 1) {
            ScrollableTabRow(
                selectedTabIndex = selectedStepIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CyberCyanPrimary,
                edgePadding = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                steps.forEachIndexed { idx, step ->
                    Tab(
                        selected = selectedStepIndex == idx,
                        onClick = {
                            selectedStepIndex = idx
                            selectedNode = null
                        },
                        text = {
                            Text("Step ${step.stepIndex}")
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Before / After / Tree Diff Selector
        TabRow(
            selectedTabIndex = viewMode.ordinal,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            contentColor = CyberCyanPrimary
        ) {
            Tab(
                selected = viewMode == SnapshotViewMode.BEFORE,
                onClick = { viewMode = SnapshotViewMode.BEFORE },
                text = { Text("Before Action") }
            )
            Tab(
                selected = viewMode == SnapshotViewMode.AFTER,
                onClick = { viewMode = SnapshotViewMode.AFTER },
                text = { Text("After Action") }
            )
            Tab(
                selected = viewMode == SnapshotViewMode.COMPARISON_DIFF,
                onClick = { viewMode = SnapshotViewMode.COMPARISON_DIFF },
                text = { Text("Tree Diff") }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (viewMode == SnapshotViewMode.COMPARISON_DIFF) {
            // Tree Comparison & Mutation Diff View
            TreeDiffView(
                diff = diff,
                activeStep = activeStep,
                selectedNode = selectedNode,
                onSelectNode = { selectedNode = it }
            )
        } else {
            // Visual Screen Canvas & Node Inspection View
            Column(modifier = Modifier.fillMaxSize()) {
                // Action Capabilities Filter Chips
                val scrollFilters = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollFilters),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ActionCapabilityFilter.values().forEach { filter ->
                        FilterChip(
                            selected = capabilityFilter == filter,
                            onClick = { capabilityFilter = filter },
                            label = { Text(filter.label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyanPrimary.copy(alpha = 0.2f),
                                selectedLabelColor = CyberCyanPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Split Area: Visual Screen Simulation + Details Card
                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val isWide = maxWidth > 600.dp
                    if (isWide) {
                        Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                ScreenViewportCanvas(
                                    snapshot = activeSnapshot,
                                    targetSelector = activeStep.targetSelector,
                                    filter = capabilityFilter,
                                    selectedNode = selectedNode,
                                    onNodeSelected = { selectedNode = it }
                                )
                            }
                            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                                NodeDetailsPanel(
                                    node = selectedNode,
                                    activeSnapshot = activeSnapshot,
                                    step = activeStep
                                )
                            }
                        }
                    } else {
                        Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.weight(1.3f).fillMaxWidth()) {
                                ScreenViewportCanvas(
                                    snapshot = activeSnapshot,
                                    targetSelector = activeStep.targetSelector,
                                    filter = capabilityFilter,
                                    selectedNode = selectedNode,
                                    onNodeSelected = { selectedNode = it }
                                )
                            }
                            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                NodeDetailsPanel(
                                    node = selectedNode,
                                    activeSnapshot = activeSnapshot,
                                    step = activeStep
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScreenViewportCanvas(
    snapshot: UiSnapshot,
    targetSelector: String?,
    filter: ActionCapabilityFilter,
    selectedNode: UiNode?,
    onNodeSelected: (UiNode?) -> Unit
) {
    val allNodes = snapshot.allNodes

    // Screen dimension normalization (standard 1080 x 2160 device viewport)
    val viewportWidth = 1080f
    val viewportHeight = 2160f

    val filteredNodes = allNodes.filter { node ->
        when (filter) {
            ActionCapabilityFilter.ALL -> true
            ActionCapabilityFilter.CLICKABLE -> node.isClickable
            ActionCapabilityFilter.LONG_CLICKABLE -> node.isLongClickable
            ActionCapabilityFilter.SCROLLABLE -> node.isScrollable
            ActionCapabilityFilter.EDITABLE -> node.isEditable
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0F172A))
            .border(2.dp, CyberCyanPrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .aspectRatio(viewportWidth / viewportHeight)
                .background(Color(0xFF020617))
                .pointerInput(filteredNodes) {
                    detectTapGestures { tapOffset ->
                        val scaleX = viewportWidth / size.width
                        val scaleY = viewportHeight / size.height
                        val realX = (tapOffset.x * scaleX).toInt()
                        val realY = (tapOffset.y * scaleY).toInt()

                        val hit = filteredNodes.lastOrNull { node ->
                            node.bounds.contains(realX, realY)
                        }
                        onNodeSelected(hit)
                    }
                }
        ) {
            val canvasW = constraints.maxWidth.toFloat()
            val canvasH = constraints.maxHeight.toFloat()
            val scaleX = canvasW / viewportWidth
            val scaleY = canvasH / viewportHeight

            Canvas(modifier = Modifier.fillMaxSize()) {
                // Draw decorative grid & status bar header
                drawRect(
                    color = Color(0xFF1E293B),
                    topLeft = Offset(0f, 0f),
                    size = Size(size.width, 24.dp.toPx())
                )

                // Draw bounding boxes of all nodes
                for (node in filteredNodes) {
                    val rect = node.bounds
                    val left = rect.left * scaleX
                    val top = rect.top * scaleY
                    val w = rect.width * scaleX
                    val h = rect.height * scaleY

                    if (w <= 0 || h <= 0) continue

                    val isTarget = !targetSelector.isNullOrEmpty() && (
                            node.text?.equals(targetSelector, ignoreCase = true) == true ||
                            node.contentDescription?.equals(targetSelector, ignoreCase = true) == true ||
                            targetSelector.contains(node.text ?: "___")
                    )

                    val isSelected = selectedNode?.id == node.id

                    val boxColor = when {
                        isSelected -> Color(0xFF00E5FF)
                        isTarget -> Color(0xFF10B981)
                        node.isEditable -> Color(0xFF38BDF8)
                        node.isClickable -> Color(0xFF34D399)
                        node.isLongClickable -> Color(0xFFA855F7)
                        node.isScrollable -> Color(0xFFF59E0B)
                        else -> Color(0x3394A3B8)
                    }

                    // Draw filled surface for target or selected
                    if (isSelected || isTarget) {
                        drawRect(
                            color = boxColor.copy(alpha = 0.25f),
                            topLeft = Offset(left, top),
                            size = Size(w, h)
                        )
                    }

                    // Draw wireframe outline
                    drawRect(
                        color = boxColor,
                        topLeft = Offset(left, top),
                        size = Size(w, h),
                        style = if (node.isScrollable) Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)) else Stroke(width = if (isSelected || isTarget) 2.5.dp.toPx() else 1.dp.toPx())
                    )
                }
            }

            // Canvas legend overlay
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .background(Color(0xCC000000), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LegendDot("Click", Color(0xFF34D399))
                LegendDot("LongClick", Color(0xFFA855F7))
                LegendDot("Scroll", Color(0xFFF59E0B))
                LegendDot("Target", Color(0xFF10B981))
                LegendDot("Selected", Color(0xFF00E5FF))
            }
        }
    }
}

@Composable
fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(3.dp))
        Text(text = label, fontSize = 9.sp, color = Color.White)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NodeDetailsPanel(
    node: UiNode?,
    activeSnapshot: UiSnapshot,
    step: StepRecordEntity
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxSize()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
    ) {
        val scrollState = rememberScrollState()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "INSPECTED UI ELEMENT",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = CyberCyanPrimary
                )
                Text(
                    text = "${activeSnapshot.totalNodeCount} nodes in window",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (node == null) {
                Text(
                    text = "Tap any highlighted element on the visual screen canvas to inspect its accessibility affordances.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Text(
                    text = node.text ?: node.contentDescription ?: node.resourceId?.substringAfterLast("/") ?: node.className.substringAfterLast("."),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanPrimary
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Capabilities Badges
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (node.isClickable) SmallBadge("Clickable", Color(0xFF34D399))
                    if (node.isLongClickable) SmallBadge("Long-Clickable", Color(0xFFA855F7))
                    if (node.isScrollable) SmallBadge("Scrollable", Color(0xFFF59E0B))
                    if (node.isEditable) SmallBadge("Editable", Color(0xFF38BDF8))
                    if (node.isFocused) SmallBadge("Focused", CyberCyanPrimary)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    node.resourceId?.let { Text("View ID: $it", fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    Text("Class: ${node.className}", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    node.text?.let { Text("Text: '$it'", fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    node.contentDescription?.let { Text("ContentDesc: '$it'", fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    Text("Bounds: (${node.bounds.left}, ${node.bounds.top}) -> (${node.bounds.right}, ${node.bounds.bottom})", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("Center Touch: (${node.bounds.centerX}, ${node.bounds.centerY}) | Size: ${node.bounds.width}x${node.bounds.height}", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Step Verification Context
            Text(
                text = "STEP VERIFICATION REPORT",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = step.verificationDetails,
                style = MaterialTheme.typography.bodySmall,
                color = if (step.status == "SUCCESS") StatusSuccess else StatusFailure,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun TreeDiffView(
    diff: SnapshotComparisonDiff,
    activeStep: StepRecordEntity,
    selectedNode: UiNode?,
    onSelectNode: (UiNode?) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Diff Summary Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "TREE MUTATION & BEHAVIORAL DELTA",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = CyberCyanPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = diff.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetadataBadge("Added", "${diff.addedCount}")
                    MetadataBadge("Removed", "${diff.removedCount}")
                    MetadataBadge("Mutated", "${diff.mutatedNodes.size}")
                    MetadataBadge("Pre Nodes", "${diff.preSnapshot?.totalNodeCount ?: 0}")
                    MetadataBadge("Post Nodes", "${diff.postSnapshot?.totalNodeCount ?: 0}")
                }
            }
        }

        // Mutated Elements List
        if (diff.mutatedNodes.isNotEmpty()) {
            Text(
                text = "Mutated UI Elements (${diff.mutatedNodes.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                diff.mutatedNodes.forEach { (pre, post) ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = post.resourceId ?: post.className.substringAfterLast("."),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = CyberCyanPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Before: '${pre.text ?: pre.contentDescription ?: "(empty)"}'", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.outline)
                                Text("After: '${post.text ?: post.contentDescription}'", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = StatusSuccess, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Verification Rule Alignment
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "INDEPENDENT VERIFIER OUTCOME",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = StatusSuccess
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = activeStep.verificationDetails,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
