package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.DiagnosticLogEntity
import com.example.data.local.StepRecordEntity
import com.example.data.local.TaskExecutionEntity
import com.example.ui.AgentUiState
import com.example.ui.AgentViewModel
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.StatusFailure
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusTimeout
import com.example.ui.theme.StatusWarning

@Composable
fun HistoryScreen(
    viewModel: AgentViewModel,
    uiState: AgentUiState,
    executions: List<TaskExecutionEntity>,
    logs: List<DiagnosticLogEntity>
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    val selectedSteps by viewModel.selectedExecutionSteps.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()

    val gallerySteps: List<StepRecordEntity> = remember(selectedSteps, engineState.steps) {
        if (selectedSteps.isNotEmpty()) {
            selectedSteps
        } else if (engineState.steps.isNotEmpty()) {
            engineState.steps.map { s ->
                StepRecordEntity(
                    id = "current_${s.stepIndex}",
                    executionId = engineState.executionId ?: "current",
                    stepIndex = s.stepIndex,
                    commandType = s.commandSummary.takeWhile { it != ' ' && it != '[' },
                    commandSummary = s.commandSummary,
                    targetSelector = s.targetSelector,
                    dispatchedAction = s.dispatchedAction,
                    status = s.status.name,
                    verificationDetails = s.verificationDetails,
                    durationMs = s.durationMs,
                    timestamp = s.timestampMs
                )
            }
        } else {
            // Default demo steps for immediate gallery inspection
            listOf(
                StepRecordEntity(
                    id = "demo_step_1",
                    executionId = "demo",
                    stepIndex = 1,
                    commandType = "LaunchApp",
                    commandSummary = "Launch Calculator",
                    targetSelector = "package='com.google.android.calculator'",
                    dispatchedAction = "Intent launch for package 'com.google.android.calculator'",
                    status = "SUCCESS",
                    verificationDetails = "Foreground window transferred to expected package 'com.google.android.calculator'",
                    durationMs = 1200L,
                    timestamp = System.currentTimeMillis()
                ),
                StepRecordEntity(
                    id = "demo_step_2",
                    executionId = "demo",
                    stepIndex = 2,
                    commandType = "ClickElement",
                    commandSummary = "Click [Button 7]",
                    targetSelector = "text='7'",
                    dispatchedAction = "Action Click dispatched to node 'com.google.android.calculator:id/digit_7' at (176, 810)",
                    status = "SUCCESS",
                    verificationDetails = "Display node 'com.google.android.calculator:id/formula' contains '7' (text: '7')",
                    durationMs = 850L,
                    timestamp = System.currentTimeMillis() + 1500L
                )
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "EXECUTION HISTORY & GALLERY",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                color = CyberCyanPrimary,
                letterSpacing = 1.2.sp
            )

            IconButton(
                onClick = { viewModel.clearAllHistory() },
                modifier = Modifier.testTag("clear_history_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Clear History",
                    tint = MaterialTheme.colorScheme.outline
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = CyberCyanPrimary
        ) {
            Tab(
                selected = selectedSubTab == 0,
                onClick = { selectedSubTab = 0 },
                text = { Text("Runs (${executions.size})") }
            )
            Tab(
                selected = selectedSubTab == 1,
                onClick = { selectedSubTab = 1 },
                text = { Text("Snapshot Gallery") }
            )
            Tab(
                selected = selectedSubTab == 2,
                onClick = { selectedSubTab = 2 },
                text = { Text("Logs (${logs.size})") }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (selectedSubTab) {
            0 -> {
                // Task Executions List
                if (executions.isEmpty()) {
                    EmptyStateView("No executions recorded yet in Room database. Run a task or open the Snapshot Gallery to view step trees.")
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().testTag("executions_list"),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(executions, key = { it.id }) { exec ->
                            TaskExecutionCard(
                                execution = exec,
                                isSelected = uiState.selectedExecutionId == exec.id,
                                onClick = {
                                    viewModel.loadExecutionSteps(exec.id)
                                    selectedSubTab = 1
                                },
                                onInspectGallery = {
                                    viewModel.loadExecutionSteps(exec.id)
                                    selectedSubTab = 1
                                }
                            )
                        }
                    }
                }
            }
            1 -> {
                // Dedicated Snapshot Gallery with Before & After screen comparisons
                SnapshotGalleryView(
                    steps = gallerySteps,
                    onCloseGallery = { selectedSubTab = 0 }
                )
            }
            2 -> {
                // Diagnostic Logs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val levels = listOf("ALL", "INFO", "WARN", "ERROR")
                    for (lvl in levels) {
                        FilterChip(
                            selected = uiState.logFilterLevel == lvl,
                            onClick = { viewModel.setLogFilterLevel(lvl) },
                            label = { Text(lvl, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyanPrimary.copy(alpha = 0.2f),
                                selectedLabelColor = CyberCyanPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                val filteredLogs = logs.filter {
                    uiState.logFilterLevel == "ALL" || it.level == uiState.logFilterLevel
                }

                if (filteredLogs.isEmpty()) {
                    EmptyStateView("No logs match level '${uiState.logFilterLevel}'.")
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                            .padding(8.dp)
                            .testTag("diagnostic_logs_list"),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredLogs, key = { it.id }) { log ->
                            DiagnosticLogRow(log = log)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TaskExecutionCard(
    execution: TaskExecutionEntity,
    isSelected: Boolean,
    onClick: () -> Unit,
    onInspectGallery: () -> Unit
) {
    val statusColor = when (execution.status) {
        "COMPLETED_SUCCESS" -> StatusSuccess
        "COMPLETED_FAILURE" -> StatusFailure
        "TIMEOUT" -> StatusTimeout
        else -> StatusWarning
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(
                1.dp,
                if (isSelected) CyberCyanPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = execution.prompt,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )

                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, statusColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = execution.status.removePrefix("COMPLETED_"),
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Steps: ${execution.successfulSteps}/${execution.totalSteps} passed • ${execution.durationMs}ms",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = onInspectGallery,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyanPrimary.copy(alpha = 0.15f),
                        contentColor = CyberCyanPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Icon(Icons.Default.Layers, contentDescription = "Gallery", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Snapshots", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            if (!execution.failureReason.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Failure: ${execution.failureReason}",
                    style = MaterialTheme.typography.bodySmall,
                    color = StatusFailure,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun DiagnosticLogRow(log: DiagnosticLogEntity) {
    val levelColor = when (log.level) {
        "ERROR" -> StatusFailure
        "WARN" -> StatusWarning
        "INFO" -> CyberCyanPrimary
        else -> MaterialTheme.colorScheme.outline
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = formatTimeOnly(log.timestamp),
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.outline,
            modifier = Modifier.width(60.dp)
        )
        Text(
            text = "[${log.level}]",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = levelColor,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(45.dp)
        )
        Text(
            text = "${log.tag}: ${log.message}",
            style = MaterialTheme.typography.bodySmall,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun EmptyStateView(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = "Empty",
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(44.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

private fun formatTimeOnly(timeMs: Long): String {
    val formatter = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
    return formatter.format(java.util.Date(timeMs))
}
