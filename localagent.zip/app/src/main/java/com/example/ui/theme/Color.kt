package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Cyan / Autonomous Agent Theme
val CyberCyanPrimary = Color(0xFF00E5FF)
val CyberCyanOnPrimary = Color(0xFF00363D)
val CyberCyanContainer = Color(0xFF004F58)
val CyberCyanOnContainer = Color(0xFF88F3FF)

val AgentIndigoSecondary = Color(0xFFA5B4FC)
val AgentIndigoOnSecondary = Color(0xFF1E2460)
val AgentIndigoContainer = Color(0xFF333B88)
val AgentIndigoOnContainer = Color(0xFFE0E7FF)

val AgentEmeraldTertiary = Color(0xFF34D399)
val AgentEmeraldOnTertiary = Color(0xFF003822)
val AgentEmeraldContainer = Color(0xFF005234)
val AgentEmeraldOnContainer = Color(0xFFA7F3D0)

val DarkBackground = Color(0xFF0A0F1D)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val DarkSurfaceTint = Color(0xFF00E5FF)
val DarkOnBackground = Color(0xFFF3F4F6)
val DarkOnSurface = Color(0xFFE5E7EB)
val DarkOnSurfaceVariant = Color(0xFF9CA3AF)
val DarkOutline = Color(0xFF374151)

val LightPrimary = Color(0xFF006876)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFA1EFFF)
val LightSecondary = Color(0xFF4355B9)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF1E293B)
val LightOutline = Color(0xFFCBD5E1)

// Status Colors
val StatusSuccess = Color(0xFF10B981)
val StatusFailure = Color(0xFFEF4444)
val StatusWarning = Color(0xFFF59E0B)
val StatusTimeout = Color(0xFFF97316)
val StatusInconclusive = Color(0xFF8B5CF6)
val StatusRunning = Color(0xFF38BDF8)
