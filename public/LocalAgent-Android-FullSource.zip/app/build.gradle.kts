plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.localagent"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.localagent"
        minSdk = 27
        targetSdk = 36
        versionCode = 250
        versionName = "2.5.0"
        
        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "armeabi-v7a"))
        }
    }
}
