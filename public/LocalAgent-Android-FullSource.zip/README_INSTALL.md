# LocalAgent Native Android Project (API 27 to API 36+)
Optimized for 4GB RAM devices (e.g., TECNO Camon i Click Helio P23).

## Quick Install on Device via ADB:
1. Connect TECNO device with USB Debugging enabled.
2. Run:
   adb install -r -g LocalAgent-v2.5-arm64-api27.apk
3. Enable Accessibility Service:
   adb shell settings put secure enabled_accessibility_services com.example.localagent/.LocalAgentAccessibilityService
   adb shell settings put secure accessibility_enabled 1
4. Whitelist from battery Doze:
   adb shell dumpsys deviceidle whitelist +com.example.localagent
